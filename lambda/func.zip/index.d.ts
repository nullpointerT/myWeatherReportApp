declare const axios: any;
declare const AWS: any;
declare let weatherInfo: any;
declare let weatherMsg: string;
declare function getWeather(): Promise<void>;
declare function processWeatherInfo(): void;
declare function main(): Promise<void>;
